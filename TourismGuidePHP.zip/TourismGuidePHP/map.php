<html lang = "en-US">
<head>
<meta charset = "UTF-8">
<meta name="viewport" content = "width=device-width,initial-scale=1">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<?php include "header.php"; ?>

</head>
<body>
<?php include "navigationbar1.php"; ?>

<div class="container" style = "margin-top : 50px">
<h2 class = "text-center" style = "font-family : 'Monotype Corsiva' ; font-weight : bold ; color : #E6120E">MP Map</h2>
<br><br><br>
<center><img src = "images/mpmap.gif"></center>


</div>


</body>
</html>
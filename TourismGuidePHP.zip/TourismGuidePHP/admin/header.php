<html>
<head>
<title>Tourism Guide</title>
<link rel="stylesheet" href = "css/mystyle.css">
</head>
</html>
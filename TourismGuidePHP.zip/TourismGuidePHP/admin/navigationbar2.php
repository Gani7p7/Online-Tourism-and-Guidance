
<nav class = "navbar navbar-expand-md bg-dark navbar-dark">
<a class = "navbar-brand" href = "#" style = "color : yellow">Tourism Guide</a>
<button class="navbar-toggler" type = "button" data-toggle="collapse" data-target="#collapsibleNavbar">
<span class = "navbar-toggler-icon"></span>
</button>

<div class = "collapse navbar-collapse" id = "collapsibleNavbar">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link" href = "../index.php" style = "color : white">Home</a>
</li>
<li class="nav-item">
<a class="nav-link" href = "../about.php" style = "color : white">About</a>
</li>
<li class="nav-item">
<a class="nav-link" href = "../contact.php" style = "color : white">Contact</a>
</li>
<li class="nav-item">
<a class="nav-link" href = "../map.php" style = "color : white">Map</a>
</li>

<li class="nav-item">
<a class="nav-link" href = "index.php" style = "color : white">Admin Login</a>
</li>

</ul>
</div>

</nav>